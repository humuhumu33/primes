"""
Tests for Axiom 1: Prime Ontology
"""
