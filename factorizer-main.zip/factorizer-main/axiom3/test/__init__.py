"""
Tests for Axiom 3: Duality Principle
"""
